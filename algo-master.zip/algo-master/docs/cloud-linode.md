## API Token

Sign into the Linode Manager and go to the
[tokens management page](https://cloud.linode.com/profile/tokens).

Click `Add a Personal Access Token`. Label your new token and select *at least* the
`Linodes` read/write permission and `StackScripts` read/write permission. 
Press `Submit` and make sure to copy the displayed token
as it won't be shown again.
